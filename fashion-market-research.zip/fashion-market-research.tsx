import { BarChart, LineChart } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function FashionMarketResearch() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-bold tracking-tight mb-4">Fashion Market Intelligence</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Comprehensive analysis of current fashion trends, emerging keywords, and competitor positioning for wholesale
          buyers.
        </p>
      </div>

      <Tabs defaultValue="trends" className="mb-12">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="trends">Trend Analysis</TabsTrigger>
          <TabsTrigger value="competitors">Competitor Analysis</TabsTrigger>
        </TabsList>
        <TabsContent value="trends" className="pt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Trending Categories</CardTitle>
                <CardDescription>Top performing product categories this season</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 flex items-center justify-center">
                  <div className="w-full space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Sustainable Activewear</span>
                        <span className="text-sm text-muted-foreground">32%</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div className="h-2 rounded-full bg-primary" style={{ width: "32%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Oversized Tailoring</span>
                        <span className="text-sm text-muted-foreground">28%</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div className="h-2 rounded-full bg-primary" style={{ width: "28%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Dopamine Dressing</span>
                        <span className="text-sm text-muted-foreground">24%</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div className="h-2 rounded-full bg-primary" style={{ width: "24%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Y2K Revival</span>
                        <span className="text-sm text-muted-foreground">16%</span>
                      </div>
                      <div className="h-2 w-full rounded-full bg-muted">
                        <div className="h-2 rounded-full bg-primary" style={{ width: "16%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Hot Keywords</CardTitle>
                <CardDescription>Terms gaining traction in fashion searches</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 pt-4">
                  <Badge className="px-3 py-1 text-sm">Sustainable</Badge>
                  <Badge className="px-3 py-1 text-sm">Upcycled</Badge>
                  <Badge className="px-3 py-1 text-sm">Genderless</Badge>
                  <Badge className="px-3 py-1 text-sm">Biodegradable</Badge>
                  <Badge className="px-3 py-1 text-sm">Artisanal</Badge>
                  <Badge className="px-3 py-1 text-sm">Deadstock</Badge>
                  <Badge className="px-3 py-1 text-sm">Circular</Badge>
                  <Badge className="px-3 py-1 text-sm">Handcrafted</Badge>
                  <Badge className="px-3 py-1 text-sm">Vintage-inspired</Badge>
                  <Badge className="px-3 py-1 text-sm">Modular</Badge>
                  <Badge className="px-3 py-1 text-sm">Adaptable</Badge>
                  <Badge className="px-3 py-1 text-sm">Timeless</Badge>
                  <Badge className="px-3 py-1 text-sm">Versatile</Badge>
                  <Badge className="px-3 py-1 text-sm">Inclusive</Badge>
                  <Badge className="px-3 py-1 text-sm">Ethical</Badge>
                </div>
              </CardContent>
            </Card>
            <Card className="md:col-span-2 lg:col-span-1">
              <CardHeader className="pb-2">
                <CardTitle>Seasonal Color Palette</CardTitle>
                <CardDescription>Dominant colors for the upcoming season</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="h-12 rounded-md bg-[#D0A98F]"></div>
                    <div className="text-xs text-center">Digital Lavender</div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-12 rounded-md bg-[#7A918D]"></div>
                    <div className="text-xs text-center">Tranquil Blue</div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-12 rounded-md bg-[#E8B298]"></div>
                    <div className="text-xs text-center">Sundial</div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-12 rounded-md bg-[#A49592]"></div>
                    <div className="text-xs text-center">Antique Moss</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Trend Forecast</CardTitle>
                <CardDescription>Projected growth of key trends over next 6 months</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px] flex items-center justify-center">
                  <LineChart className="h-60 w-60 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Regional Trend Variations</CardTitle>
                <CardDescription>How trends differ across major markets</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">North America</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Athleisure dominance</li>
                      <li>• Comfort-focused luxury</li>
                      <li>• Sustainable materials</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Europe</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Artisanal craftsmanship</li>
                      <li>• Heritage revival</li>
                      <li>• Circular fashion models</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Asia</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Tech-integrated garments</li>
                      <li>• Streetwear evolution</li>
                      <li>• Gender-fluid designs</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Middle East</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Modest luxury</li>
                      <li>• Statement accessories</li>
                      <li>• Cultural fusion</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="competitors" className="pt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Market Share Analysis</CardTitle>
                <CardDescription>Competitive landscape of major fashion wholesalers</CardDescription>
              </CardHeader>
              <CardContent className="px-2">
                <div className="h-[300px] flex items-center justify-center">
                  <BarChart className="h-60 w-60 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Pricing Strategy Comparison</CardTitle>
                <CardDescription>How your competitors are positioning their products</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm font-medium">Competitor A</div>
                      <div className="text-xs text-muted-foreground">Premium positioning</div>
                    </div>
                    <div className="font-medium">$$$</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm font-medium">Competitor B</div>
                      <div className="text-xs text-muted-foreground">Mid-market focus</div>
                    </div>
                    <div className="font-medium">$$</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm font-medium">Competitor C</div>
                      <div className="text-xs text-muted-foreground">Value-oriented</div>
                    </div>
                    <div className="font-medium">$</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-sm font-medium">Your Brand</div>
                      <div className="text-xs text-muted-foreground">Current positioning</div>
                    </div>
                    <div className="font-medium">$$</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-3">
              <CardHeader>
                <CardTitle>Competitor Strengths & Weaknesses</CardTitle>
                <CardDescription>Analysis of major competitors in the wholesale fashion market</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-3">
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                        <span className="font-semibold">A</span>
                      </div>
                      <div>
                        <h3 className="font-medium">Competitor A</h3>
                        <p className="text-sm text-muted-foreground">Premium Wholesale</p>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Strengths</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Strong luxury brand partnerships</li>
                        <li>• Exclusive designer collections</li>
                        <li>• Superior quality control</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Weaknesses</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Limited sustainable options</li>
                        <li>• High minimum order quantities</li>
                        <li>• Slow to adapt to trends</li>
                      </ul>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                        <span className="font-semibold">B</span>
                      </div>
                      <div>
                        <h3 className="font-medium">Competitor B</h3>
                        <p className="text-sm text-muted-foreground">Fast Fashion Wholesale</p>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Strengths</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Rapid trend adoption</li>
                        <li>• Competitive pricing</li>
                        <li>• Low minimum orders</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Weaknesses</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Quality inconsistencies</li>
                        <li>• Limited exclusivity</li>
                        <li>• Sustainability concerns</li>
                      </ul>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                        <span className="font-semibold">C</span>
                      </div>
                      <div>
                        <h3 className="font-medium">Competitor C</h3>
                        <p className="text-sm text-muted-foreground">Sustainable Wholesale</p>
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Strengths</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Certified sustainable materials</li>
                        <li>• Transparent supply chain</li>
                        <li>• Strong ethical positioning</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium mb-2">Weaknesses</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Higher price points</li>
                        <li>• Limited style variety</li>
                        <li>• Longer lead times</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Market Opportunities</CardTitle>
                <CardDescription>Gaps in the market based on competitor analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Sustainable Mid-Market</h3>
                    <p className="text-sm text-muted-foreground">
                      Gap between affordable fast fashion and premium sustainable options presents opportunity for
                      mid-priced eco-conscious collections.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Size-Inclusive Luxury</h3>
                    <p className="text-sm text-muted-foreground">
                      Limited premium offerings in extended size ranges presents growth opportunity in inclusive luxury
                      segment.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Tech-Enhanced Basics</h3>
                    <p className="text-sm text-muted-foreground">
                      Functional everyday wear with integrated technology features remains underserved by major
                      wholesalers.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Competitive Differentiation</CardTitle>
                <CardDescription>Recommended positioning strategies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Quality-to-Price Ratio</h3>
                    <p className="text-sm text-muted-foreground">
                      Position between fast fashion's low prices and luxury's high quality by offering superior
                      materials at accessible price points.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Flexible Ordering</h3>
                    <p className="text-sm text-muted-foreground">
                      Differentiate with lower minimum order quantities and more flexible terms than competitors A and C
                      to attract small-to-medium retailers.
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-medium mb-2">Trend Forecasting Services</h3>
                    <p className="text-sm text-muted-foreground">
                      Bundle trend analysis and merchandising consultation with wholesale orders to add value beyond
                      product offering.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

