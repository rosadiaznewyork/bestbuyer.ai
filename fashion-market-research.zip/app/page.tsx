"use client"

import FashionMarketResearch from "../fashion-market-research"

export default function SyntheticV0PageForDeployment() {
  return <FashionMarketResearch />
}